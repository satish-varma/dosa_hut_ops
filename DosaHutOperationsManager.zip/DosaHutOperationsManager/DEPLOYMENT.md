# Deployment Guide - Dosa Hut Operations Manager

This guide covers the complete deployment process for the Dosa Hut Operations Manager mobile application, including building for production, app store submissions, and Firebase configuration.

## 🏗️ Pre-Deployment Checklist

### Code Quality
- [ ] All TypeScript errors resolved
- [ ] ESLint warnings addressed
- [ ] Unit tests passing
- [ ] Integration tests completed
- [ ] Performance optimization reviewed

### Firebase Configuration
- [ ] Firestore security rules deployed
- [ ] Firebase Storage rules deployed
- [ ] Firebase Authentication configured
- [ ] API keys secured
- [ ] Production environment variables set

### App Configuration
- [ ] App name and version updated
- [ ] Icons and splash screens created
- [ ] Package name configured correctly
- [ ] Permissions properly declared
- [ ] Signing certificates generated

## 🔥 Firebase Deployment

### 1. Install Firebase CLI
```bash
npm install -g firebase-tools
firebase login
```

### 2. Initialize Firebase Project
```bash
firebase init
# Select Firestore, Storage, and Functions (if using)
```

### 3. Deploy Firestore Rules
```bash
firebase deploy --only firestore:rules
```

### 4. Deploy Storage Rules
```bash
firebase deploy --only storage
```

### 5. Verify Deployment
```bash
firebase projects:list
firebase firestore:databases:list
```

## 🤖 Android Deployment

### 1. Generate Signing Key
```bash
cd android/app
keytool -genkeypair -v -storetype PKCS12 -keystore my-upload-key.keystore -alias my-key-alias -keyalg RSA -keysize 2048 -validity 10000
```

### 2. Configure Signing in Gradle
Edit `android/gradle.properties`:
```properties
MYAPP_UPLOAD_STORE_FILE=my-upload-key.keystore
MYAPP_UPLOAD_KEY_ALIAS=my-key-alias
MYAPP_UPLOAD_STORE_PASSWORD=*****
MYAPP_UPLOAD_KEY_PASSWORD=*****
```

Edit `android/app/build.gradle`:
```gradle
android {
    ...
    signingConfigs {
        release {
            if (project.hasProperty('MYAPP_UPLOAD_STORE_FILE')) {
                storeFile file(MYAPP_UPLOAD_STORE_FILE)
                storePassword MYAPP_UPLOAD_STORE_PASSWORD
                keyAlias MYAPP_UPLOAD_KEY_ALIAS
                keyPassword MYAPP_UPLOAD_KEY_PASSWORD
            }
        }
    }
    buildTypes {
        release {
            ...
            signingConfig signingConfigs.release
        }
    }
}
```

### 3. Build Release APK
```bash
cd android
./gradlew assembleRelease
```

### 4. Build AAB for Play Store
```bash
cd android
./gradlew bundleRelease
```

### 5. Test Release Build
```bash
npx react-native run-android --variant=release
```

### 6. Upload to Google Play Console
1. Go to [Google Play Console](https://play.google.com/console)
2. Create new application
3. Upload the AAB file from `android/app/build/outputs/bundle/release/`
4. Complete app information, screenshots, and descriptions
5. Submit for review

## 🍎 iOS Deployment

### 1. Open Xcode Project
```bash
cd ios
open DosaHutOperationsManager.xcworkspace
```

### 2. Configure Signing & Capabilities
- Select your development team
- Update bundle identifier to match Firebase config
- Enable required capabilities (Push Notifications, etc.)

### 3. Archive for Distribution
1. Select "Any iOS Device" as target
2. Product → Archive
3. Wait for archive to complete

### 4. Export for App Store
1. In Organizer, select your archive
2. Click "Distribute App"
3. Choose "App Store Connect"
4. Select distribution options
5. Export and upload

### 5. Submit to App Store
1. Go to [App Store Connect](https://appstoreconnect.apple.com)
2. Create new app
3. Upload your IPA file
4. Complete app information and metadata
5. Submit for review

## 🔧 Environment Configuration

### Production Environment Variables
Create `.env.production`:
```env
# Firebase Configuration
FIREBASE_API_KEY=AIzaSyArSGFXI4aNIHyEG2kEEmNfh38A08MX0RE
FIREBASE_AUTH_DOMAIN=dosa-hut-3a8d4.firebaseapp.com
FIREBASE_PROJECT_ID=dosa-hut-3a8d4
FIREBASE_STORAGE_BUCKET=dosa-hut-3a8d4.firebasestorage.app
FIREBASE_MESSAGING_SENDER_ID=430650707483
FIREBASE_APP_ID=1:430650707483:android:f4b9c194bd9ef52deb32be

# App Configuration
APP_VERSION=1.0.0
API_BASE_URL=https://api.dosahut.com
SUPPORT_EMAIL=support@dosahut.com
```

### Staging Environment
Create `.env.staging`:
```env
# Firebase Staging Configuration
FIREBASE_PROJECT_ID=dosa-hut-staging
# ... other staging configs
```

## 📱 App Store Metadata

### App Information
- **App Name**: Dosa Hut Operations Manager
- **Subtitle**: Restaurant Operations Management
- **Keywords**: restaurant, operations, management, dosa, firebase, inventory, sales, expenses
- **Description**: See [APP_STORE_DESCRIPTION.md](APP_STORE_DESCRIPTION.md)

### Screenshots Required
- **iPhone**: 6.7", 6.5", 5.5"
- **iPad**: 12.9", 11"
- **Android**: Phone, 7" Tablet, 10" Tablet

### Categories
- **Primary**: Business
- **Secondary**: Productivity

## 🚀 Release Process

### Version Management
```bash
# Update version in package.json
npm version patch|minor|major

# Update Android version
# Edit android/app/build.gradle
# versionCode and versionName

# Update iOS version
# Edit ios/DosaHutOperationsManager/Info.plist
# CFBundleShortVersionString and CFBundleVersion
```

### Release Checklist
1. [ ] Code freeze and final testing
2. [ ] Version numbers updated
3. [ ] Changelog updated
4. [ ] Firebase rules deployed
5. [ ] Production builds created
6. [ ] Internal testing completed
7. [ ] App store submissions made
8. [ ] Release notes prepared
9. [ ] Marketing materials ready
10. [ ] Support documentation updated

## 🔍 Testing Before Release

### Manual Testing
- [ ] Authentication flow (login/register/logout)
- [ ] All navigation screens working
- [ ] Data persistence and sync
- [ ] Image upload functionality
- [ ] Offline functionality
- [ ] Performance on low-end devices

### Automated Testing
```bash
# Run unit tests
npm test

# Run E2E tests
npx detox build --configuration android.emu.release
npx detox test --configuration android.emu.release
```

### Device Testing
- [ ] Android 8.0+ (API 26+)
- [ ] iOS 12.0+
- [ ] Various screen sizes
- [ ] Different device orientations
- [ ] Network connectivity issues
- [ ] Low storage scenarios

## 📊 Performance Optimization

### Bundle Size Analysis
```bash
# Analyze Android bundle
cd android
./gradlew bundleRelease
bundletool analyze-apks --bundle=app/build/outputs/bundle/release/app-release.aab

# Analyze iOS bundle
# Use Xcode's App Size Report
```

### Performance Monitoring
- Enable Firebase Performance Monitoring
- Set up Crashlytics
- Monitor app startup time
- Track memory usage
- Monitor network requests

## 🔒 Security Considerations

### Code Obfuscation
```gradle
// android/app/build.gradle
android {
    buildTypes {
        release {
            minifyEnabled true
            proguardFiles getDefaultProguardFile("proguard-android.txt"), "proguard-rules.pro"
        }
    }
}
```

### API Security
- [ ] All API keys secured
- [ ] Firestore rules tested
- [ ] Storage rules validated
- [ ] Authentication tokens secured
- [ ] SSL/TLS certificates valid

## 📋 Post-Release Monitoring

### App Store Analytics
- Monitor download numbers
- Track user ratings and reviews
- Analyze crash reports
- Monitor performance metrics

### Firebase Analytics
- User engagement metrics
- Feature usage tracking
- Retention rates
- Error tracking

### Support Preparation
- [ ] Support documentation ready
- [ ] FAQ updated
- [ ] Support team trained
- [ ] Escalation procedures defined

## 🚨 Rollback Procedures

### If Issues Found After Release
1. **Immediate**: Remove from app stores (if critical)
2. **Firebase**: Rollback database rules if needed
3. **Hotfix**: Prepare emergency patch
4. **Communication**: Notify users about issues
5. **Resolution**: Deploy fixed version ASAP

### Emergency Contacts
- **Developer Team**: dev@dosahut.com
- **Firebase Support**: Use Firebase Console
- **App Store Support**: Use respective developer consoles

## 📞 Support Information

### Release Support
- **Email**: releases@dosahut.com
- **Slack**: #releases-dosa-hut
- **Phone**: +91-XXXXXXXXXX (Emergency only)

### Documentation
- [Firebase Setup Guide](FIREBASE_SETUP.md)
- [Troubleshooting Guide](TROUBLESHOOTING.md)
- [API Documentation](API_DOCS.md)

---

**Note**: Always test the complete deployment process in a staging environment before proceeding with production deployment.