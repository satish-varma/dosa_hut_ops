import React, { createContext, useContext, useEffect, useState, ReactNode } from 'react';
import { auth, createUserDocument } from '../services/firebase';
import { User } from '../types';
import AsyncStorage from '@react-native-async-storage/async-storage';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (email: string, password: string, restaurantName: string, displayName: string) => Promise<void>;
  logout: () => Promise<void>;
  resetPassword: (email: string) => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = auth().onAuthStateChanged(async (firebaseUser) => {
      if (firebaseUser) {
        try {
          const userRef = await createUserDocument(firebaseUser, {});
          if (userRef) {
            const userDoc = await userRef.get();
            const userData = userDoc.data();
            if (userData) {
              const userObject: User = {
                uid: firebaseUser.uid,
                email: firebaseUser.email!,
                displayName: userData.displayName || firebaseUser.displayName,
                restaurantName: userData.restaurantName || '',
                createdAt: userData.createdAt?.toDate() || new Date(),
                role: userData.role || 'owner',
              };
              setUser(userObject);
              await AsyncStorage.setItem('user', JSON.stringify(userObject));
            }
          }
        } catch (error) {
          console.error('Error fetching user data:', error);
        }
      } else {
        setUser(null);
        await AsyncStorage.removeItem('user');
      }
      setLoading(false);
    });

    // Load user from AsyncStorage on app start
    loadUserFromStorage();

    return unsubscribe;
  }, []);

  const loadUserFromStorage = async () => {
    try {
      const storedUser = await AsyncStorage.getItem('user');
      if (storedUser) {
        setUser(JSON.parse(storedUser));
      }
    } catch (error) {
      console.error('Error loading user from storage:', error);
    }
  };

  const login = async (email: string, password: string) => {
    try {
      await auth().signInWithEmailAndPassword(email, password);
    } catch (error: any) {
      throw new Error(error.message);
    }
  };

  const register = async (
    email: string,
    password: string,
    restaurantName: string,
    displayName: string
  ) => {
    try {
      const { user: firebaseUser } = await auth().createUserWithEmailAndPassword(email, password);
      
      if (firebaseUser) {
        await firebaseUser.updateProfile({ displayName });
        await createUserDocument(firebaseUser, {
          restaurantName,
          role: 'owner',
          displayName,
        });
      }
    } catch (error: any) {
      throw new Error(error.message);
    }
  };

  const logout = async () => {
    try {
      await auth().signOut();
    } catch (error: any) {
      throw new Error(error.message);
    }
  };

  const resetPassword = async (email: string) => {
    try {
      await auth().sendPasswordResetEmail(email);
    } catch (error: any) {
      throw new Error(error.message);
    }
  };

  const value: AuthContextType = {
    user,
    loading,
    login,
    register,
    logout,
    resetPassword,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};