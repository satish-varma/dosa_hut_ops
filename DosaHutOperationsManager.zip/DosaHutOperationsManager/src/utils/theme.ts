import { MD3LightTheme, configureFonts } from 'react-native-paper';

const fontConfig = {
  default: {
    regular: {
      fontFamily: 'System',
      fontWeight: 'normal',
    },
    medium: {
      fontFamily: 'System',
      fontWeight: '500',
    },
    light: {
      fontFamily: 'System',
      fontWeight: '300',
    },
    thin: {
      fontFamily: 'System',
      fontWeight: '100',
    },
  },
};

export const theme = {
  ...MD3LightTheme,
  fonts: configureFonts({ config: fontConfig }),
  colors: {
    ...MD3LightTheme.colors,
    primary: '#F26422', // Warm Orange
    secondary: '#FFFDD0', // Cream
    background: '#FFFEF7', // Light cream background
    surface: '#FFFFFF',
    surfaceVariant: '#FFF8E1',
    onSurface: '#2D1810', // Dark brown text
    onSurfaceVariant: '#5D4037',
    onPrimary: '#FFFFFF',
    onSecondary: '#2D1810',
    success: '#4CAF50',
    error: '#F44336',
    warning: '#FF9800',
    info: '#2196F3',
    // Custom colors for Dosa Hut
    cream: '#FFFDD0',
    warmOrange: '#F26422',
    darkBrown: '#2D1810',
    lightCream: '#FFFEF7',
    cardBackground: '#FFFFFF',
    shadowColor: '#00000020',
  },
  roundness: 12,
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const elevation = {
  small: 2,
  medium: 4,
  large: 8,
};

export type Theme = typeof theme;