import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, Image, Alert } from 'react-native';
import { 
  Text, 
  TextInput, 
  Button, 
  Surface,
  Appbar,
  Menu,
  Card,
  Snackbar,
} from 'react-native-paper';
import DatePicker from 'react-native-date-picker';
import { launchImageLibrary, MediaType } from 'react-native-image-picker';
import { useNavigation, useRoute } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { firestore, storage, COLLECTIONS } from '../../services/firebase';
import { Expense, EXPENSE_CATEGORIES } from '../../types';
import { theme, spacing } from '../../utils/theme';

const AddExpenseScreen: React.FC = () => {
  const route = useRoute();
  const editingExpense = (route.params as any)?.expense as Expense | undefined;
  
  const [formData, setFormData] = useState({
    amount: '',
    category: EXPENSE_CATEGORIES[0],
    description: '',
    date: new Date(),
  });
  const [receiptImage, setReceiptImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [showDatePicker, setShowDatePicker] = useState(false);
  const [categoryMenuVisible, setCategoryMenuVisible] = useState(false);
  const [snackbarVisible, setSnackbarVisible] = useState(false);
  const [snackbarMessage, setSnackbarMessage] = useState('');

  const navigation = useNavigation();
  const { user } = useAuth();

  useEffect(() => {
    if (editingExpense) {
      setFormData({
        amount: editingExpense.amount.toString(),
        category: editingExpense.category,
        description: editingExpense.description,
        date: editingExpense.date,
      });
      setReceiptImage(editingExpense.receiptUrl || null);
    }
  }, [editingExpense]);

  const handleInputChange = (field: string, value: string | Date) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const pickImage = () => {
    const options = {
      mediaType: 'photo' as MediaType,
      quality: 0.8,
      maxWidth: 1000,
      maxHeight: 1000,
    };

    launchImageLibrary(options, (response) => {
      if (response.assets && response.assets[0]) {
        setReceiptImage(response.assets[0].uri || null);
      }
    });
  };

  const uploadImage = async (imageUri: string): Promise<string> => {
    const filename = `receipts/${user?.uid}/${Date.now()}.jpg`;
    const reference = storage().ref(filename);
    
    await reference.putFile(imageUri);
    return await reference.getDownloadURL();
  };

  const validateForm = () => {
    const { amount, description } = formData;

    if (!amount || parseFloat(amount) <= 0) {
      showSnackbar('Please enter a valid amount');
      return false;
    }

    if (!description.trim()) {
      showSnackbar('Please enter a description');
      return false;
    }

    return true;
  };

  const saveExpense = async () => {
    if (!validateForm() || !user) return;

    setLoading(true);
    try {
      let receiptUrl = editingExpense?.receiptUrl || null;

      // Upload new image if selected
      if (receiptImage && receiptImage !== editingExpense?.receiptUrl) {
        receiptUrl = await uploadImage(receiptImage);
      }

      const expenseData = {
        userId: user.uid,
        amount: parseFloat(formData.amount),
        category: formData.category,
        description: formData.description.trim(),
        date: formData.date,
        receiptUrl,
        createdAt: editingExpense?.createdAt || new Date(),
      };

      if (editingExpense) {
        // Update existing expense
        await firestore()
          .collection(COLLECTIONS.EXPENSES)
          .doc(editingExpense.id)
          .update(expenseData);
        showSnackbar('Expense updated successfully');
      } else {
        // Create new expense
        await firestore()
          .collection(COLLECTIONS.EXPENSES)
          .add(expenseData);
        showSnackbar('Expense added successfully');
      }

      navigation.goBack();
    } catch (error) {
      console.error('Error saving expense:', error);
      showSnackbar('Failed to save expense');
    } finally {
      setLoading(false);
    }
  };

  const deleteExpense = async () => {
    if (!editingExpense) return;

    Alert.alert(
      'Delete Expense',
      'Are you sure you want to delete this expense?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await firestore()
                .collection(COLLECTIONS.EXPENSES)
                .doc(editingExpense.id)
                .delete();
              
              // Delete image if exists
              if (editingExpense.receiptUrl) {
                try {
                  const imageRef = storage().refFromURL(editingExpense.receiptUrl);
                  await imageRef.delete();
                } catch (error) {
                  console.log('Error deleting image:', error);
                }
              }

              showSnackbar('Expense deleted successfully');
              navigation.goBack();
            } catch (error) {
              console.error('Error deleting expense:', error);
              showSnackbar('Failed to delete expense');
            }
          },
        },
      ]
    );
  };

  const showSnackbar = (message: string) => {
    setSnackbarMessage(message);
    setSnackbarVisible(true);
  };

  return (
    <Surface style={styles.container}>
      <Appbar.Header>
        <Appbar.BackAction onPress={() => navigation.goBack()} />
        <Appbar.Content title={editingExpense ? 'Edit Expense' : 'Add Expense'} />
        {editingExpense && (
          <Appbar.Action icon="delete" onPress={deleteExpense} />
        )}
      </Appbar.Header>

      <ScrollView style={styles.content}>
        <Card style={styles.card}>
          <Card.Content>
            <TextInput
              label="Amount (₹)"
              value={formData.amount}
              onChangeText={(value) => handleInputChange('amount', value)}
              mode="outlined"
              style={styles.input}
              keyboardType="numeric"
              left={<TextInput.Icon icon="currency-inr" />}
            />

            <View style={styles.menuContainer}>
              <Text style={styles.label}>Category</Text>
              <Menu
                visible={categoryMenuVisible}
                onDismiss={() => setCategoryMenuVisible(false)}
                anchor={
                  <Button
                    mode="outlined"
                    onPress={() => setCategoryMenuVisible(true)}
                    contentStyle={styles.menuButton}
                    style={styles.categoryButton}
                  >
                    {formData.category}
                  </Button>
                }
              >
                {EXPENSE_CATEGORIES.map((category) => (
                  <Menu.Item
                    key={category}
                    title={category}
                    onPress={() => {
                      handleInputChange('category', category);
                      setCategoryMenuVisible(false);
                    }}
                  />
                ))}
              </Menu>
            </View>

            <TextInput
              label="Description"
              value={formData.description}
              onChangeText={(value) => handleInputChange('description', value)}
              mode="outlined"
              style={styles.input}
              multiline
              numberOfLines={3}
              left={<TextInput.Icon icon="text" />}
            />

            <View style={styles.dateContainer}>
              <Text style={styles.label}>Date</Text>
              <Button
                mode="outlined"
                onPress={() => setShowDatePicker(true)}
                contentStyle={styles.dateButton}
                icon="calendar"
              >
                {formData.date.toLocaleDateString('en-IN')}
              </Button>
            </View>

            <View style={styles.receiptContainer}>
              <Text style={styles.label}>Receipt (Optional)</Text>
              <Button
                mode="outlined"
                onPress={pickImage}
                style={styles.imageButton}
                icon="camera"
              >
                {receiptImage ? 'Change Receipt' : 'Add Receipt'}
              </Button>
              
              {receiptImage && (
                <Card style={styles.imagePreview}>
                  <Image source={{ uri: receiptImage }} style={styles.previewImage} />
                </Card>
              )}
            </View>
          </Card.Content>
        </Card>

        <Button
          mode="contained"
          onPress={saveExpense}
          loading={loading}
          disabled={loading}
          style={styles.saveButton}
          contentStyle={styles.saveButtonContent}
        >
          {editingExpense ? 'Update Expense' : 'Save Expense'}
        </Button>
      </ScrollView>

      <DatePicker
        modal
        open={showDatePicker}
        date={formData.date}
        mode="date"
        maximumDate={new Date()}
        onConfirm={(date) => {
          setShowDatePicker(false);
          handleInputChange('date', date);
        }}
        onCancel={() => {
          setShowDatePicker(false);
        }}
      />

      <Snackbar
        visible={snackbarVisible}
        onDismiss={() => setSnackbarVisible(false)}
        duration={3000}
      >
        {snackbarMessage}
      </Snackbar>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    flex: 1,
    padding: spacing.md,
  },
  card: {
    marginBottom: spacing.lg,
  },
  input: {
    marginBottom: spacing.md,
  },
  label: {
    fontSize: 16,
    color: theme.colors.onSurface,
    marginBottom: spacing.sm,
  },
  menuContainer: {
    marginBottom: spacing.md,
  },
  menuButton: {
    justifyContent: 'flex-start',
  },
  categoryButton: {
    alignSelf: 'flex-start',
  },
  dateContainer: {
    marginBottom: spacing.md,
  },
  dateButton: {
    justifyContent: 'flex-start',
  },
  receiptContainer: {
    marginBottom: spacing.md,
  },
  imageButton: {
    alignSelf: 'flex-start',
    marginBottom: spacing.md,
  },
  imagePreview: {
    overflow: 'hidden',
  },
  previewImage: {
    width: '100%',
    height: 200,
    resizeMode: 'cover',
  },
  saveButton: {
    marginBottom: spacing.xl,
  },
  saveButtonContent: {
    paddingVertical: spacing.sm,
  },
});

export default AddExpenseScreen;