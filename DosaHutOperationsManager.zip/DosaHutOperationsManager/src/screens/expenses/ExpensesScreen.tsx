import React, { useState, useEffect } from 'react';
import { View, StyleSheet, FlatList, RefreshControl } from 'react-native';
import { 
  Text, 
  Card, 
  FAB,
  Appbar,
  Surface,
  Searchbar,
  Chip,
  Menu,
  Button,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { firestore, COLLECTIONS } from '../../services/firebase';
import { Expense, EXPENSE_CATEGORIES } from '../../types';
import { theme, spacing } from '../../utils/theme';

const ExpensesScreen: React.FC = () => {
  const [expenses, setExpenses] = useState<Expense[]>([]);
  const [filteredExpenses, setFilteredExpenses] = useState<Expense[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [menuVisible, setMenuVisible] = useState(false);

  const navigation = useNavigation();
  const { user } = useAuth();

  useFocusEffect(
    React.useCallback(() => {
      loadExpenses();
    }, [user])
  );

  useEffect(() => {
    filterExpenses();
  }, [expenses, searchQuery, selectedCategory]);

  const loadExpenses = async () => {
    if (!user) return;

    try {
      const expensesSnapshot = await firestore()
        .collection(COLLECTIONS.EXPENSES)
        .where('userId', '==', user.uid)
        .orderBy('date', 'desc')
        .get();

      const expensesData = expensesSnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data(),
        date: doc.data().date.toDate(),
        createdAt: doc.data().createdAt.toDate(),
      })) as Expense[];

      setExpenses(expensesData);
    } catch (error) {
      console.error('Error loading expenses:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterExpenses = () => {
    let filtered = expenses;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(expense => expense.category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(expense =>
        expense.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        expense.category.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    setFilteredExpenses(filtered);
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadExpenses();
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString('en-IN')}`;
  };

  const formatDate = (date: Date) => {
    return date.toLocaleDateString('en-IN', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const editExpense = (expense: Expense) => {
    navigation.navigate('AddExpense' as never, { expense } as never);
  };

  const deleteExpense = async (expenseId: string) => {
    try {
      await firestore()
        .collection(COLLECTIONS.EXPENSES)
        .doc(expenseId)
        .delete();
      
      setExpenses(prev => prev.filter(expense => expense.id !== expenseId));
    } catch (error) {
      console.error('Error deleting expense:', error);
    }
  };

  const getTotalExpenses = () => {
    return filteredExpenses.reduce((total, expense) => total + expense.amount, 0);
  };

  const ExpenseCard = ({ item }: { item: Expense }) => (
    <Card style={styles.expenseCard} onPress={() => editExpense(item)}>
      <Card.Content>
        <View style={styles.expenseHeader}>
          <View style={styles.expenseInfo}>
            <Text style={styles.expenseDescription}>{item.description}</Text>
            <Text style={styles.expenseDate}>{formatDate(item.date)}</Text>
          </View>
          <View style={styles.expenseAmount}>
            <Text style={styles.amountText}>{formatCurrency(item.amount)}</Text>
            <Chip mode="outlined" compact>{item.category}</Chip>
          </View>
        </View>
        {item.receiptUrl && (
          <View style={styles.receiptIndicator}>
            <Icon name="attachment" size={16} color={theme.colors.primary} />
            <Text style={styles.receiptText}>Receipt attached</Text>
          </View>
        )}
      </Card.Content>
    </Card>
  );

  const renderEmpty = () => (
    <View style={styles.emptyContainer}>
      <Icon name="receipt-text-outline" size={64} color={theme.colors.onSurfaceVariant} />
      <Text style={styles.emptyTitle}>No Expenses Found</Text>
      <Text style={styles.emptySubtitle}>
        {searchQuery || selectedCategory !== 'All' 
          ? 'Try adjusting your filters' 
          : 'Start by adding your first expense'
        }
      </Text>
      <Button
        mode="contained"
        onPress={() => navigation.navigate('AddExpense' as never)}
        style={styles.emptyButton}
      >
        Add Expense
      </Button>
    </View>
  );

  return (
    <Surface style={styles.container}>
      <Appbar.Header>
        <Appbar.Content title="Expenses" />
        <Appbar.Action
          icon="filter"
          onPress={() => setMenuVisible(true)}
        />
      </Appbar.Header>

      <View style={styles.content}>
        <Searchbar
          placeholder="Search expenses..."
          value={searchQuery}
          onChangeText={setSearchQuery}
          style={styles.searchbar}
        />

        <View style={styles.filterRow}>
          <Text style={styles.filterLabel}>Category: </Text>
          <Menu
            visible={menuVisible}
            onDismiss={() => setMenuVisible(false)}
            anchor={
              <Chip
                onPress={() => setMenuVisible(true)}
                mode="outlined"
                icon="chevron-down"
              >
                {selectedCategory}
              </Chip>
            }
          >
            <Menu.Item
              title="All"
              onPress={() => {
                setSelectedCategory('All');
                setMenuVisible(false);
              }}
            />
            {EXPENSE_CATEGORIES.map((category) => (
              <Menu.Item
                key={category}
                title={category}
                onPress={() => {
                  setSelectedCategory(category);
                  setMenuVisible(false);
                }}
              />
            ))}
          </Menu>
        </View>

        <Card style={styles.summaryCard}>
          <Card.Content>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryLabel}>
                Total ({filteredExpenses.length} expenses):
              </Text>
              <Text style={styles.summaryAmount}>
                {formatCurrency(getTotalExpenses())}
              </Text>
            </View>
          </Card.Content>
        </Card>

        <FlatList
          data={filteredExpenses}
          renderItem={ExpenseCard}
          keyExtractor={(item) => item.id}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
          }
          ListEmptyComponent={renderEmpty}
          contentContainerStyle={
            filteredExpenses.length === 0 ? styles.emptyList : styles.list
          }
        />
      </View>

      <FAB
        icon="plus"
        style={styles.fab}
        onPress={() => navigation.navigate('AddExpense' as never)}
      />
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    flex: 1,
    padding: spacing.md,
  },
  searchbar: {
    marginBottom: spacing.md,
  },
  filterRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.md,
  },
  filterLabel: {
    fontSize: 16,
    color: theme.colors.onSurface,
    marginRight: spacing.sm,
  },
  summaryCard: {
    marginBottom: spacing.md,
    backgroundColor: theme.colors.primaryContainer,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryLabel: {
    fontSize: 16,
    color: theme.colors.onPrimaryContainer,
  },
  summaryAmount: {
    fontSize: 18,
    fontWeight: 'bold',
    color: theme.colors.primary,
  },
  list: {
    paddingBottom: spacing.xxl,
  },
  expenseCard: {
    marginBottom: spacing.md,
    backgroundColor: theme.colors.surface,
    elevation: 2,
  },
  expenseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  expenseInfo: {
    flex: 1,
    marginRight: spacing.md,
  },
  expenseDescription: {
    fontSize: 16,
    fontWeight: '500',
    color: theme.colors.onSurface,
    marginBottom: spacing.xs,
  },
  expenseDate: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
  },
  expenseAmount: {
    alignItems: 'flex-end',
  },
  amountText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: theme.colors.error,
    marginBottom: spacing.xs,
  },
  receiptIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.sm,
  },
  receiptText: {
    fontSize: 12,
    color: theme.colors.primary,
    marginLeft: spacing.xs,
  },
  emptyList: {
    flex: 1,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.xl,
  },
  emptyTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: theme.colors.onSurface,
    marginTop: spacing.lg,
    marginBottom: spacing.sm,
  },
  emptySubtitle: {
    fontSize: 16,
    color: theme.colors.onSurfaceVariant,
    textAlign: 'center',
    marginBottom: spacing.xl,
  },
  emptyButton: {
    paddingHorizontal: spacing.lg,
  },
  fab: {
    position: 'absolute',
    right: spacing.md,
    bottom: spacing.md,
    backgroundColor: theme.colors.primary,
  },
});

export default ExpensesScreen;