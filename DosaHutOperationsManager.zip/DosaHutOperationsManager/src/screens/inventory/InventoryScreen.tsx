import React from 'react';
import { View, StyleSheet } from 'react-native';
import { Text, Surface, Appbar } from 'react-native-paper';
import { theme, spacing } from '../../utils/theme';

const InventoryScreen: React.FC = () => {
  return (
    <Surface style={styles.container}>
      <Appbar.Header>
        <Appbar.Content title="Inventory" />
      </Appbar.Header>
      <View style={styles.content}>
        <Text style={styles.title}>Inventory Screen</Text>
        <Text style={styles.subtitle}>Coming soon...</Text>
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: spacing.lg,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: theme.colors.onSurface,
    marginBottom: spacing.sm,
  },
  subtitle: {
    fontSize: 16,
    color: theme.colors.onSurfaceVariant,
  },
});

export default InventoryScreen;