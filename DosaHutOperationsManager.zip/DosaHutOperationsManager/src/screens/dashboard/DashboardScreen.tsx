import React, { useState, useEffect } from 'react';
import { View, StyleSheet, ScrollView, RefreshControl } from 'react-native';
import { 
  Text, 
  Card, 
  FAB,
  Appbar,
  Surface,
  Button,
  Chip,
} from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../../contexts/AuthContext';
import { firestore, COLLECTIONS } from '../../services/firebase';
import { DashboardMetrics } from '../../types';
import { theme, spacing } from '../../utils/theme';

const DashboardScreen: React.FC = () => {
  const [metrics, setMetrics] = useState<DashboardMetrics>({
    dailySales: 0,
    dailyExpenses: 0,
    lowStockItems: 0,
    totalStaff: 0,
    monthlyRevenue: 0,
    monthlyExpenses: 0,
  });
  const [refreshing, setRefreshing] = useState(false);
  const [fabOpen, setFabOpen] = useState(false);

  const navigation = useNavigation();
  const { user, logout } = useAuth();

  useEffect(() => {
    if (user) {
      loadDashboardData();
    }
  }, [user]);

  const loadDashboardData = async () => {
    if (!user) return;

    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
      const monthEnd = new Date(today.getFullYear(), today.getMonth() + 1, 0, 23, 59, 59);

      // Get daily sales
      const dailySalesSnapshot = await firestore()
        .collection(COLLECTIONS.SALES)
        .where('userId', '==', user.uid)
        .where('date', '>=', today)
        .where('date', '<', tomorrow)
        .get();

      const dailySales = dailySalesSnapshot.docs.reduce((total, doc) => {
        return total + (doc.data().amount || 0);
      }, 0);

      // Get daily expenses
      const dailyExpensesSnapshot = await firestore()
        .collection(COLLECTIONS.EXPENSES)
        .where('userId', '==', user.uid)
        .where('date', '>=', today)
        .where('date', '<', tomorrow)
        .get();

      const dailyExpenses = dailyExpensesSnapshot.docs.reduce((total, doc) => {
        return total + (doc.data().amount || 0);
      }, 0);

      // Get monthly sales
      const monthlySalesSnapshot = await firestore()
        .collection(COLLECTIONS.SALES)
        .where('userId', '==', user.uid)
        .where('date', '>=', monthStart)
        .where('date', '<=', monthEnd)
        .get();

      const monthlyRevenue = monthlySalesSnapshot.docs.reduce((total, doc) => {
        return total + (doc.data().amount || 0);
      }, 0);

      // Get monthly expenses
      const monthlyExpensesSnapshot = await firestore()
        .collection(COLLECTIONS.EXPENSES)
        .where('userId', '==', user.uid)
        .where('date', '>=', monthStart)
        .where('date', '<=', monthEnd)
        .get();

      const monthlyExpenses = monthlyExpensesSnapshot.docs.reduce((total, doc) => {
        return total + (doc.data().amount || 0);
      }, 0);

      // Get low stock items
      const inventorySnapshot = await firestore()
        .collection(COLLECTIONS.INVENTORY)
        .where('userId', '==', user.uid)
        .get();

      const lowStockItems = inventorySnapshot.docs.filter(doc => {
        const data = doc.data();
        return data.quantity <= data.threshold;
      }).length;

      // Get total active staff
      const staffSnapshot = await firestore()
        .collection(COLLECTIONS.STAFF)
        .where('userId', '==', user.uid)
        .where('status', '==', 'active')
        .get();

      const totalStaff = staffSnapshot.size;

      setMetrics({
        dailySales,
        dailyExpenses,
        lowStockItems,
        totalStaff,
        monthlyRevenue,
        monthlyExpenses,
      });
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadDashboardData();
    setRefreshing(false);
  };

  const formatCurrency = (amount: number) => {
    return `₹${amount.toLocaleString('en-IN')}`;
  };

  const navigateToAdd = (screen: string) => {
    setFabOpen(false);
    navigation.navigate(screen as never);
  };

  const MetricCard = ({ title, value, icon, color, subtitle }: any) => (
    <Card style={styles.metricCard}>
      <Card.Content>
        <View style={styles.metricHeader}>
          <Icon name={icon} size={24} color={color} />
          <Text style={styles.metricTitle}>{title}</Text>
        </View>
        <Text style={[styles.metricValue, { color }]}>{value}</Text>
        {subtitle && <Text style={styles.metricSubtitle}>{subtitle}</Text>}
      </Card.Content>
    </Card>
  );

  return (
    <Surface style={styles.container}>
      <Appbar.Header style={styles.header}>
        <Appbar.Content 
          title={`Welcome, ${user?.displayName || 'User'}`} 
          subtitle={user?.restaurantName}
        />
        <Appbar.Action icon="logout" onPress={logout} />
      </Appbar.Header>

      <ScrollView
        style={styles.content}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Overview</Text>
          <View style={styles.metricsRow}>
            <MetricCard
              title="Sales"
              value={formatCurrency(metrics.dailySales)}
              icon="cash"
              color={theme.colors.success}
              subtitle="Today"
            />
            <MetricCard
              title="Expenses"
              value={formatCurrency(metrics.dailyExpenses)}
              icon="receipt"
              color={theme.colors.error}
              subtitle="Today"
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Monthly Summary</Text>
          <View style={styles.metricsRow}>
            <MetricCard
              title="Revenue"
              value={formatCurrency(metrics.monthlyRevenue)}
              icon="trending-up"
              color={theme.colors.primary}
              subtitle="This Month"
            />
            <MetricCard
              title="Expenses"
              value={formatCurrency(metrics.monthlyExpenses)}
              icon="trending-down"
              color={theme.colors.warning}
              subtitle="This Month"
            />
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Operations</Text>
          <View style={styles.metricsRow}>
            <MetricCard
              title="Staff"
              value={metrics.totalStaff.toString()}
              icon="account-group"
              color={theme.colors.info}
              subtitle="Active"
            />
            <MetricCard
              title="Low Stock"
              value={metrics.lowStockItems.toString()}
              icon="alert-circle"
              color={metrics.lowStockItems > 0 ? theme.colors.error : theme.colors.success}
              subtitle="Items"
            />
          </View>
        </View>

        {metrics.lowStockItems > 0 && (
          <Card style={styles.alertCard}>
            <Card.Content>
              <View style={styles.alertHeader}>
                <Icon name="alert" size={24} color={theme.colors.error} />
                <Text style={styles.alertTitle}>Low Stock Alert</Text>
              </View>
              <Text style={styles.alertText}>
                {metrics.lowStockItems} items are running low on stock. 
                Check your inventory to reorder.
              </Text>
              <Button
                mode="outlined"
                onPress={() => navigation.navigate('Inventory' as never)}
                style={styles.alertButton}
              >
                View Inventory
              </Button>
            </Card.Content>
          </Card>
        )}

        <Card style={styles.quickActionsCard}>
          <Card.Content>
            <Text style={styles.sectionTitle}>Quick Actions</Text>
            <View style={styles.quickActions}>
              <Button
                mode="contained-tonal"
                icon="cash-plus"
                onPress={() => navigateToAdd('AddSale')}
                style={styles.quickActionButton}
              >
                Add Sale
              </Button>
              <Button
                mode="contained-tonal"
                icon="receipt-text"
                onPress={() => navigateToAdd('AddExpense')}
                style={styles.quickActionButton}
              >
                Add Expense
              </Button>
              <Button
                mode="contained-tonal"
                icon="package-variant"
                onPress={() => navigation.navigate('Inventory' as never)}
                style={styles.quickActionButton}
              >
                Inventory
              </Button>
              <Button
                mode="contained-tonal"
                icon="account-plus"
                onPress={() => navigateToAdd('AddStaff')}
                style={styles.quickActionButton}
              >
                Add Staff
              </Button>
            </View>
          </Card.Content>
        </Card>
      </ScrollView>

      <FAB.Group
        open={fabOpen}
        visible
        icon={fabOpen ? 'close' : 'plus'}
        actions={[
          {
            icon: 'cash-plus',
            label: 'Add Sale',
            onPress: () => navigateToAdd('AddSale'),
          },
          {
            icon: 'receipt-text',
            label: 'Add Expense',
            onPress: () => navigateToAdd('AddExpense'),
          },
          {
            icon: 'account-plus',
            label: 'Add Staff',
            onPress: () => navigateToAdd('AddStaff'),
          },
          {
            icon: 'package-variant-add',
            label: 'Add Inventory',
            onPress: () => navigateToAdd('AddInventory'),
          },
        ]}
        onStateChange={({ open }) => setFabOpen(open)}
        onPress={() => {
          if (fabOpen) {
            // do something if the speed dial is open
          }
        }}
      />
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    backgroundColor: theme.colors.primary,
  },
  content: {
    flex: 1,
    padding: spacing.md,
  },
  section: {
    marginBottom: spacing.lg,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: theme.colors.onSurface,
    marginBottom: spacing.md,
  },
  metricsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: spacing.md,
  },
  metricCard: {
    flex: 1,
    backgroundColor: theme.colors.surface,
    elevation: 2,
  },
  metricHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  metricTitle: {
    fontSize: 14,
    color: theme.colors.onSurfaceVariant,
    marginLeft: spacing.sm,
    flex: 1,
  },
  metricValue: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: spacing.xs,
  },
  metricSubtitle: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
  },
  alertCard: {
    backgroundColor: theme.colors.errorContainer,
    marginBottom: spacing.lg,
  },
  alertHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: spacing.sm,
  },
  alertTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: theme.colors.error,
    marginLeft: spacing.sm,
  },
  alertText: {
    fontSize: 14,
    color: theme.colors.onErrorContainer,
    marginBottom: spacing.md,
  },
  alertButton: {
    alignSelf: 'flex-start',
  },
  quickActionsCard: {
    marginBottom: spacing.xxl,
  },
  quickActions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: spacing.md,
  },
  quickActionButton: {
    flex: 1,
    minWidth: '45%',
  },
});

export default DashboardScreen;