import auth from '@react-native-firebase/auth';
import firestore from '@react-native-firebase/firestore';
import storage from '@react-native-firebase/storage';

// Enable Firestore offline persistence
firestore().settings({
  persistence: true,
  cacheSizeBytes: firestore.CACHE_SIZE_UNLIMITED,
});

export { auth, firestore, storage };

// Firebase configuration (already configured via google-services.json)
export const firebaseConfig = {
  projectId: 'dosa-hut-3a8d4',
  storageBucket: 'dosa-hut-3a8d4.firebasestorage.app',
  apiKey: 'AIzaSyArSGFXI4aNIHyEG2kEEmNfh38A08MX0RE',
  authDomain: 'dosa-hut-3a8d4.firebaseapp.com',
  messagingSenderId: '430650707483',
  appId: '1:430650707483:android:f4b9c194bd9ef52deb32be',
};

// Collections
export const COLLECTIONS = {
  USERS: 'users',
  EXPENSES: 'expenses',
  SALES: 'sales',
  STAFF: 'staff',
  INVENTORY: 'inventory',
  ASSETS: 'assets',
} as const;

// Helper function to create user document
export const createUserDocument = async (user: any, additionalData: any) => {
  if (!user) return;
  
  const userRef = firestore().collection(COLLECTIONS.USERS).doc(user.uid);
  const snapShot = await userRef.get();
  
  if (!snapShot.exists) {
    const { displayName, email } = user;
    const createdAt = new Date();
    
    try {
      await userRef.set({
        displayName,
        email,
        createdAt,
        ...additionalData,
      });
    } catch (error) {
      console.log('Error creating user document', error);
    }
  }
  
  return userRef;
};