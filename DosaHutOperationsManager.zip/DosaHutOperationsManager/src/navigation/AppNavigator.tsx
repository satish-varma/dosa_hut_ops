import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useAuth } from '../contexts/AuthContext';
import { RootStackParamList, TabParamList } from '../types';

// Auth Screens
import LoginScreen from '../screens/auth/LoginScreen';
import RegisterScreen from '../screens/auth/RegisterScreen';

// Main Screens
import DashboardScreen from '../screens/dashboard/DashboardScreen';
import ExpensesScreen from '../screens/expenses/ExpensesScreen';
import AddExpenseScreen from '../screens/expenses/AddExpenseScreen';
import SalesScreen from '../screens/sales/SalesScreen';
import AddSaleScreen from '../screens/sales/AddSaleScreen';
import StaffScreen from '../screens/staff/StaffScreen';
import AddStaffScreen from '../screens/staff/AddStaffScreen';
import InventoryScreen from '../screens/inventory/InventoryScreen';
import AddInventoryScreen from '../screens/inventory/AddInventoryScreen';
import AssetsScreen from '../screens/assets/AssetsScreen';
import AddAssetScreen from '../screens/assets/AddAssetScreen';

// Components
import LoadingScreen from '../components/LoadingScreen';
import TabBar from '../components/TabBar';

const Stack = createNativeStackNavigator<RootStackParamList>();
const Tab = createBottomTabNavigator<TabParamList>();

const TabNavigator = () => {
  return (
    <Tab.Navigator
      tabBar={(props) => <TabBar {...props} />}
      screenOptions={{
        headerShown: false,
      }}
    >
      <Tab.Screen 
        name="Dashboard" 
        component={DashboardScreen}
        options={{
          tabBarLabel: 'Dashboard',
          tabBarIcon: 'home',
        }}
      />
      <Tab.Screen 
        name="Expenses" 
        component={ExpensesScreen}
        options={{
          tabBarLabel: 'Expenses',
          tabBarIcon: 'receipt',
        }}
      />
      <Tab.Screen 
        name="Sales" 
        component={SalesScreen}
        options={{
          tabBarLabel: 'Sales',
          tabBarIcon: 'cash',
        }}
      />
      <Tab.Screen 
        name="Staff" 
        component={StaffScreen}
        options={{
          tabBarLabel: 'Staff',
          tabBarIcon: 'account-group',
        }}
      />
      <Tab.Screen 
        name="Inventory" 
        component={InventoryScreen}
        options={{
          tabBarLabel: 'Inventory',
          tabBarIcon: 'package-variant',
        }}
      />
      <Tab.Screen 
        name="Assets" 
        component={AssetsScreen}
        options={{
          tabBarLabel: 'Assets',
          tabBarIcon: 'tools',
        }}
      />
    </Tab.Navigator>
  );
};

const AuthNavigator = () => {
  return (
    <Stack.Navigator screenOptions={{ headerShown: false }}>
      <Stack.Screen name="Login" component={LoginScreen} />
      <Stack.Screen name="Register" component={RegisterScreen} />
    </Stack.Navigator>
  );
};

const MainNavigator = () => {
  return (
    <Stack.Navigator>
      <Stack.Screen 
        name="Main" 
        component={TabNavigator} 
        options={{ headerShown: false }}
      />
      <Stack.Screen 
        name="AddExpense" 
        component={AddExpenseScreen}
        options={{
          title: 'Add Expense',
          presentation: 'modal',
        }}
      />
      <Stack.Screen 
        name="AddSale" 
        component={AddSaleScreen}
        options={{
          title: 'Add Sale',
          presentation: 'modal',
        }}
      />
      <Stack.Screen 
        name="AddStaff" 
        component={AddStaffScreen}
        options={{
          title: 'Add Staff Member',
          presentation: 'modal',
        }}
      />
      <Stack.Screen 
        name="AddInventory" 
        component={AddInventoryScreen}
        options={{
          title: 'Add Inventory Item',
          presentation: 'modal',
        }}
      />
      <Stack.Screen 
        name="AddAsset" 
        component={AddAssetScreen}
        options={{
          title: 'Add Asset',
          presentation: 'modal',
        }}
      />
    </Stack.Navigator>
  );
};

export const AppNavigator = () => {
  const { user, loading } = useAuth();

  if (loading) {
    return <LoadingScreen />;
  }

  return (
    <NavigationContainer>
      {user ? <MainNavigator /> : <AuthNavigator />}
    </NavigationContainer>
  );
};