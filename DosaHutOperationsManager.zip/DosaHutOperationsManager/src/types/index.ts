export interface User {
  uid: string;
  email: string;
  displayName?: string;
  restaurantName: string;
  createdAt: Date;
  role: 'owner' | 'manager' | 'staff';
}

export interface Expense {
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: Date;
  description: string;
  receiptUrl?: string;
  createdAt: Date;
}

export interface Sale {
  id: string;
  userId: string;
  amount: number;
  paymentMethod: 'cash' | 'card' | 'upi';
  orderType: 'dine-in' | 'takeaway' | 'delivery';
  items: SaleItem[];
  date: Date;
  createdAt: Date;
}

export interface SaleItem {
  name: string;
  quantity: number;
  price: number;
  total: number;
}

export interface Staff {
  id: string;
  userId: string;
  name: string;
  role: string;
  phone: string;
  email?: string;
  salary: number;
  joinDate: Date;
  status: 'active' | 'inactive';
  notes?: string;
  createdAt: Date;
}

export interface InventoryItem {
  id: string;
  userId: string;
  itemName: string;
  quantity: number;
  unit: string;
  threshold: number;
  category: string;
  supplier?: string;
  lastUpdated: Date;
  createdAt: Date;
}

export interface Asset {
  id: string;
  userId: string;
  assetName: string;
  condition: 'good' | 'needs-repair' | 'damaged';
  purchaseDate: Date;
  warranty?: Date;
  notes?: string;
  imageUrl?: string;
  createdAt: Date;
}

export interface DashboardMetrics {
  dailySales: number;
  dailyExpenses: number;
  lowStockItems: number;
  totalStaff: number;
  monthlyRevenue: number;
  monthlyExpenses: number;
}

export type RootStackParamList = {
  Auth: undefined;
  Main: undefined;
  Login: undefined;
  Register: undefined;
  Dashboard: undefined;
  Expenses: undefined;
  AddExpense: { expense?: Expense };
  Sales: undefined;
  AddSale: { sale?: Sale };
  Staff: undefined;
  AddStaff: { staff?: Staff };
  Inventory: undefined;
  AddInventory: { item?: InventoryItem };
  Assets: undefined;
  AddAsset: { asset?: Asset };
  Profile: undefined;
};

export type TabParamList = {
  Dashboard: undefined;
  Expenses: undefined;
  Sales: undefined;
  Staff: undefined;
  Inventory: undefined;
  Assets: undefined;
};

export interface FormField {
  label: string;
  value: string;
  error?: string;
  required?: boolean;
  type?: 'text' | 'email' | 'password' | 'number' | 'date';
  multiline?: boolean;
}

export const EXPENSE_CATEGORIES = [
  'Groceries',
  'Utilities', 
  'Staff Salaries',
  'Rent',
  'Equipment',
  'Marketing',
  'Transportation',
  'Other'
] as const;

export const INVENTORY_CATEGORIES = [
  'Vegetables',
  'Spices',
  'Oils',
  'Grains',
  'Dairy',
  'Packaging',
  'Cleaning',
  'Other'
] as const;

export type ExpenseCategory = typeof EXPENSE_CATEGORIES[number];
export type InventoryCategory = typeof INVENTORY_CATEGORIES[number];