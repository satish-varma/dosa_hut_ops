import React from 'react';
import { View, StyleSheet } from 'react-native';
import { ActivityIndicator, Text, Surface } from 'react-native-paper';
import { theme, spacing } from '../utils/theme';

const LoadingScreen: React.FC = () => {
  return (
    <Surface style={styles.container}>
      <View style={styles.content}>
        <Text style={styles.title}>Dosa Hut</Text>
        <Text style={styles.subtitle}>Operations Manager</Text>
        <ActivityIndicator 
          size="large" 
          color={theme.colors.primary}
          style={styles.indicator}
        />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    alignItems: 'center',
    padding: spacing.xl,
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    color: theme.colors.primary,
    marginBottom: spacing.xs,
  },
  subtitle: {
    fontSize: 18,
    color: theme.colors.onSurfaceVariant,
    marginBottom: spacing.xl,
  },
  indicator: {
    marginVertical: spacing.lg,
  },
  loadingText: {
    fontSize: 16,
    color: theme.colors.onSurfaceVariant,
  },
});

export default LoadingScreen;