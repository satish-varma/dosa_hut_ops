import React from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';
import { Text, Surface } from 'react-native-paper';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import { theme, spacing, elevation } from '../utils/theme';
import { BottomTabBarProps } from '@react-navigation/bottom-tabs';

const TabBar: React.FC<BottomTabBarProps> = ({ state, descriptors, navigation }) => {
  const getIconName = (routeName: string): string => {
    switch (routeName) {
      case 'Dashboard': return 'home';
      case 'Expenses': return 'receipt';
      case 'Sales': return 'cash';
      case 'Staff': return 'account-group';
      case 'Inventory': return 'package-variant';
      case 'Assets': return 'tools';
      default: return 'help-circle';
    }
  };

  return (
    <Surface style={styles.container} elevation={elevation.medium}>
      {state.routes.map((route, index) => {
        const { options } = descriptors[route.key];
        const label = options.tabBarLabel as string || route.name;
        const isFocused = state.index === index;
        const iconName = getIconName(route.name);

        const onPress = () => {
          const event = navigation.emit({
            type: 'tabPress',
            target: route.key,
            canPreventDefault: true,
          });

          if (!isFocused && !event.defaultPrevented) {
            navigation.navigate(route.name);
          }
        };

        return (
          <TouchableOpacity
            key={route.key}
            onPress={onPress}
            style={[
              styles.tab,
              isFocused && styles.activeTab,
            ]}
            activeOpacity={0.7}
          >
            <View style={[
              styles.iconContainer,
              isFocused && styles.activeIconContainer,
            ]}>
              <Icon
                name={iconName}
                size={24}
                color={isFocused ? theme.colors.primary : theme.colors.onSurfaceVariant}
              />
            </View>
            <Text
              style={[
                styles.label,
                isFocused && styles.activeLabel,
              ]}
              numberOfLines={1}
            >
              {label}
            </Text>
          </TouchableOpacity>
        );
      })}
    </Surface>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    backgroundColor: theme.colors.surface,
    paddingTop: spacing.sm,
    paddingBottom: spacing.md,
    paddingHorizontal: spacing.sm,
  },
  tab: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: spacing.sm,
    paddingHorizontal: spacing.xs,
  },
  activeTab: {
    // Active tab styling handled by individual elements
  },
  iconContainer: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: spacing.xs,
  },
  activeIconContainer: {
    backgroundColor: theme.colors.secondaryContainer,
  },
  label: {
    fontSize: 12,
    color: theme.colors.onSurfaceVariant,
    textAlign: 'center',
  },
  activeLabel: {
    color: theme.colors.primary,
    fontWeight: '600',
  },
});

export default TabBar;