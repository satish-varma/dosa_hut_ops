# Dosa Hut Operations Manager

A complete React Native mobile application for restaurant operations management with Firebase backend integration.

![App Version](https://img.shields.io/badge/version-1.0.0-blue.svg)
![React Native](https://img.shields.io/badge/React%20Native-0.72.6-blue.svg)
![Firebase](https://img.shields.io/badge/Firebase-v9-orange.svg)

## 🍽️ Overview

Dosa Hut Operations Manager is a production-ready mobile application designed to streamline restaurant operations. It provides comprehensive management tools for expenses, sales, staff, inventory, and assets with real-time data synchronization and offline support.

## ✨ Features

### 🔐 Authentication System
- Firebase Authentication with email/password
- User registration with restaurant profile creation
- Password reset functionality
- Session management and auto-login
- User profile management

### 📊 Dashboard (Home Screen)
- Real-time metrics display (daily sales, expenses, inventory alerts)
- Quick action buttons for common tasks
- Charts showing sales trends and expense breakdowns
- Low stock alerts and notifications
- Recent activity feed

### 💰 Expense Management
- Add/edit/delete expenses with categories
- Receipt photo upload to Firebase Storage
- Expense categorization (groceries, utilities, staff salaries, etc.)
- Date filtering and search functionality
- Monthly/weekly expense reports with charts
- Real-time sync across devices

### 💵 Sales Tracking
- Record daily sales transactions
- Payment method tracking (cash, card, UPI)
- Order type classification (dine-in, takeaway, delivery)
- Sales analytics with charts and trends
- Daily/weekly/monthly sales summaries
- Export sales reports

### 👥 Staff Management
- Staff profile creation (name, role, contact, salary)
- Attendance tracking system
- Shift scheduling
- Employee performance notes
- Contact management
- Archive/activate staff members

### 📦 Inventory Management
- Item tracking with quantities and units
- Low stock threshold alerts
- Inventory adjustment logs
- Category-based organization
- Supplier information
- Stock movement history

### 🛠️ Asset Management
- Equipment and asset registry
- Condition tracking (good, needs repair, damaged)
- Purchase date and warranty information
- Maintenance scheduling
- Asset photos and documentation
- Depreciation tracking

## 🚀 Technology Stack

### Frontend
- **React Native** 0.72.6 (CLI)
- **React Navigation** 6+ for navigation
- **React Native Paper** for Material Design 3 UI
- **React Native Vector Icons** for icons
- **React Native Image Picker** for photo uploads
- **React Native Date Picker** for date selection
- **AsyncStorage** for offline data caching

### Backend
- **Firebase Authentication** for user management
- **Cloud Firestore** for real-time database
- **Firebase Storage** for image uploads
- **Firebase Analytics** for app usage tracking

### Development Tools
- **TypeScript** for type safety
- **ESLint** and **Prettier** for code quality
- **Metro** bundler for React Native

## 📱 Installation & Setup

### Prerequisites
- Node.js (v16 or higher)
- React Native CLI
- Android Studio (for Android development)
- Xcode (for iOS development - macOS only)
- Firebase project setup

### 1. Clone the Repository
```bash
git clone https://github.com/your-username/dosa-hut-operations-manager.git
cd dosa-hut-operations-manager
```

### 2. Install Dependencies
```bash
npm install
```

### 3. Firebase Configuration
1. Create a Firebase project at [Firebase Console](https://console.firebase.google.com)
2. Enable Authentication, Firestore, and Storage
3. Add your Android/iOS apps to the Firebase project
4. Download `google-services.json` (Android) and place it in `android/app/`
5. Download `GoogleService-Info.plist` (iOS) and add it to your iOS project
6. Deploy security rules:
   ```bash
   firebase deploy --only firestore:rules
   firebase deploy --only storage
   ```

### 4. Android Setup
```bash
cd android
./gradlew clean
cd ..
npx react-native run-android
```

### 5. iOS Setup (macOS only)
```bash
cd ios
pod install
cd ..
npx react-native run-ios
```

## 🔧 Configuration

### Firebase Project Settings
- **Project ID**: `dosa-hut-3a8d4`
- **Storage Bucket**: `dosa-hut-3a8d4.firebasestorage.app`
- **Package Name**: `com.dosahut.app`

### Environment Variables
Create a `.env` file in the root directory:
```env
FIREBASE_API_KEY=your_api_key
FIREBASE_AUTH_DOMAIN=your_auth_domain
FIREBASE_PROJECT_ID=dosa-hut-3a8d4
FIREBASE_STORAGE_BUCKET=dosa-hut-3a8d4.firebasestorage.app
```

## 🏗️ Project Structure

```
src/
├── components/          # Reusable UI components
├── contexts/           # React contexts (Auth, etc.)
├── hooks/              # Custom React hooks
├── navigation/         # Navigation configuration
├── screens/            # Screen components
│   ├── auth/          # Authentication screens
│   ├── dashboard/     # Dashboard screen
│   ├── expenses/      # Expense management
│   ├── sales/         # Sales tracking
│   ├── staff/         # Staff management
│   ├── inventory/     # Inventory management
│   └── assets/        # Asset management
├── services/          # Firebase and API services
├── types/             # TypeScript type definitions
└── utils/             # Utility functions and theme
```

## 🎨 Design System

### Color Palette
- **Primary**: Warm Orange (`#F26422`)
- **Secondary**: Cream (`#FFFDD0`)
- **Background**: Light cream (`#FFFEF7`)
- **Surface**: White (`#FFFFFF`)
- **Text**: Dark brown (`#2D1810`)

### Typography
- Material Design 3 typography system
- System fonts for cross-platform consistency

## 📊 Database Schema

### Firestore Collections

#### Users
```typescript
{
  uid: string;
  email: string;
  displayName: string;
  restaurantName: string;
  createdAt: Date;
  role: 'owner' | 'manager' | 'staff';
}
```

#### Expenses
```typescript
{
  id: string;
  userId: string;
  amount: number;
  category: string;
  date: Date;
  description: string;
  receiptUrl?: string;
  createdAt: Date;
}
```

#### Sales
```typescript
{
  id: string;
  userId: string;
  amount: number;
  paymentMethod: 'cash' | 'card' | 'upi';
  orderType: 'dine-in' | 'takeaway' | 'delivery';
  items: SaleItem[];
  date: Date;
  createdAt: Date;
}
```

## 🔒 Security

### Authentication
- Firebase Authentication with email/password
- Secure session management
- Password reset functionality

### Data Security
- Firestore security rules ensure users can only access their own data
- Firebase Storage rules protect uploaded files
- All API calls are authenticated

### Privacy
- No personal data sharing
- Local data encryption
- GDPR compliant data handling

## 🚀 Building for Production

### Android APK
```bash
cd android
./gradlew assembleRelease
```

### Android AAB (Play Store)
```bash
cd android
./gradlew bundleRelease
```

### iOS IPA (App Store)
1. Open `ios/DosaHutOperationsManager.xcworkspace` in Xcode
2. Select "Any iOS Device" as target
3. Product → Archive
4. Export for App Store distribution

## 📦 Deployment

### Firebase Deployment
```bash
# Deploy Firestore rules
firebase deploy --only firestore:rules

# Deploy Storage rules
firebase deploy --only storage
```

### App Store Deployment
1. **Google Play Store**: Upload the AAB file to Google Play Console
2. **Apple App Store**: Upload the IPA file to App Store Connect

## 🧪 Testing

### Unit Tests
```bash
npm test
```

### E2E Tests
```bash
# Install Detox (if not already installed)
npm install -g detox-cli

# Build and test
detox build --configuration android.emu.debug
detox test --configuration android.emu.debug
```

## 📈 Performance Optimization

- **Offline Support**: Firebase offline persistence enabled
- **Image Optimization**: Automatic image compression and resizing
- **Memory Management**: Efficient list rendering with FlatList
- **Bundle Size**: Tree shaking and code splitting implemented

## 🐛 Troubleshooting

### Common Issues

1. **Build Failed - Android**
   ```bash
   cd android
   ./gradlew clean
   cd ..
   npx react-native run-android
   ```

2. **Firebase Connection Issues**
   - Verify `google-services.json` is in `android/app/`
   - Check Firebase project configuration
   - Ensure internet connectivity

3. **Metro Bundle Error**
   ```bash
   npx react-native start --reset-cache
   ```

4. **iOS Build Issues**
   ```bash
   cd ios
   pod install
   cd ..
   ```

## 🤝 Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- 📧 Email: support@dosahut.com
- 📱 WhatsApp: +91-XXXXXXXXXX
- 🌐 Website: https://dosahut.com

## 📚 Documentation

- [API Documentation](docs/api.md)
- [Component Documentation](docs/components.md)
- [Firebase Setup Guide](docs/firebase-setup.md)
- [Deployment Guide](docs/deployment.md)

## 🎯 Roadmap

### Phase 1 (Current)
- ✅ Authentication system
- ✅ Dashboard with real-time metrics
- ✅ Expense management
- 🔄 Sales tracking (in progress)
- 🔄 Staff management (in progress)

### Phase 2
- 📅 Inventory management
- 📅 Asset management
- 📅 Reports and analytics
- 📅 Backup and restore

### Phase 3
- 📅 Multi-language support
- 📅 Dark mode
- 📅 Push notifications
- 📅 Multiple restaurant locations

## 📞 Contact

**Dosa Hut Operations Team**
- Website: https://dosahut.com
- Email: operations@dosahut.com
- Phone: +91-XXXXXXXXXX

---

**Built with ❤️ for restaurant operations management**
